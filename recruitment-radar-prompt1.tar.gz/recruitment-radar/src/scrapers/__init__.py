"""Scrapery portali pracy."""

from src.scrapers.base import (
    BaseScraper,
    ContractKind,
    JobOffer,
    SalaryPeriod,
    SalaryRange,
    ScraperError,
    ScraperHTTPError,
    ScraperTimeoutError,
    SearchParams,
    Seniority,
    WorkMode,
)
from src.scrapers.justjoin import JustJoinScraper

__all__ = [
    "BaseScraper",
    "ContractKind",
    "JobOffer",
    "JustJoinScraper",
    "SalaryPeriod",
    "SalaryRange",
    "ScraperError",
    "ScraperHTTPError",
    "ScraperTimeoutError",
    "SearchParams",
    "Seniority",
    "WorkMode",
]
